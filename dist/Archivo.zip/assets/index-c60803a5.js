import{j as r}from"./index-4e8d4208.js";import{s as e}from"./styled-components.browser.esm-b8878f14.js";const o=e.div`
  ${{marginLeft:"0px",marginRight:"0px",marginBottom:"0px",marginTop:"20px",display:"flex",width:"100%",flexShrink:"0",whiteSpace:"nowrap",borderWidth:"0px",textAlign:"center",textTransform:"uppercase",lineHeight:"normal"}}
  &:before {
    ${{top:"7px",width:"10%",alignSelf:"center",borderTopWidth:"thin",borderStyle:"solid","--tw-border-opacity":"1",borderColor:"rgb(160 174 192 / var(--tw-border-opacity))"}}

    content: '';
  }
  &:after {
    ${{width:"90%",alignSelf:"center",borderTopWidth:"thin",borderStyle:"solid","--tw-border-opacity":"1",borderColor:"rgb(160 174 192 / var(--tw-border-opacity))"}}
    content: '';
  }
`,i=e.span`
  ${{display:"inline-block",paddingLeft:"0.625rem",paddingRight:"0.625rem",fontSize:"0.75rem",lineHeight:"1rem",letterSpacing:"0.21px"}}
`,n=e.p`
  ${{margin:"0px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontSize:"0.75rem",lineHeight:"normal",fontWeight:"500",textTransform:"uppercase",letterSpacing:"0.21px","--tw-text-opacity":"1",color:"rgb(160 174 192 / var(--tw-text-opacity))"}}
`,a=({description:t})=>r.jsx(o,{role:"separator",children:r.jsx(i,{children:r.jsx(n,{children:t})})}),d=a;export{d as default};
